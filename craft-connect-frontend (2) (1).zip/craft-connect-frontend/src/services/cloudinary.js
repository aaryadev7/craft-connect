
const CLOUD_NAME = "zlb4cssw";
const UPLOAD_PRESET = "craft_connect_upload";

export async function uploadImage(file) {
  const data = new FormData();
  data.append("file", file);
  data.append("upload_preset", UPLOAD_PRESET);

  const response = await fetch(
    `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`,
    {
      method: "POST",
      body: data,
    }
  );

  if (!response.ok) {
    throw new Error("Image upload failed");
  }

  const result = await response.json();
  return result.secure_url;
}
