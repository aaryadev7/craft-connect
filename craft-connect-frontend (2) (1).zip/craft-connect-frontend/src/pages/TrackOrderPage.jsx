import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function TrackOrderPage() {
  const [orderId, setOrderId] = useState('');
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  async function handleTrack(e) {
    e.preventDefault();
    if (!orderId.trim()) return;

    setLoading(true);
    setError('');
    setOrder(null);

    try {
      const data = await apiRequest(`/api/orders/${orderId.trim()}`);
      setOrder(data);
    } catch (err) {
      setError(err.message || 'Order not found. Please verify your Order ID.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ maxWidth: '800px', margin: '3rem auto', padding: '0 1.5rem', fontFamily: 'sans-serif' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <Link to="/customer/dashboard" style={{ textDecoration: 'none', color: '#8c6d53', fontWeight: 'bold' }}>
          ← Back to Marketplace
        </Link>
      </header>

      <h1 style={{ color: '#2c2523', marginBottom: '0.5rem' }}>📍 Track Your Order</h1>
      <p style={{ color: '#666', lineHeight: '1.5' }}>
        Enter your numeric Order ID below to view real-time delivery and fulfillment status.
      </p>

      <form onSubmit={handleTrack} style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
        <input
          type="text"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          placeholder="Enter Order ID..."
          style={{ flex: 1, padding: '0.8rem 1rem', border: '1px solid #dcd6cd', borderRadius: '8px', fontSize: '1rem' }}
          required
        />
        <button
          type="submit"
          disabled={loading}
          style={{ padding: '0.8rem 1.5rem', backgroundColor: '#8c6d53', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold' }}
        >
          {loading ? 'Searching...' : 'Track Order'}
        </button>
      </form>

      {error && (
        <div style={{ marginTop: '1.5rem', padding: '1rem', backgroundColor: '#fef2f2', border: '1px solid #fecaca', borderRadius: '8px', color: '#dc2626' }}>
          ⚠️ {error}
        </div>
      )}

      {order && (
        <div style={{ marginTop: '2.5rem', padding: '1.5rem', backgroundColor: '#faf8f5', border: '1px solid #e8e2d8', borderRadius: '12px' }}>
          <h2 style={{ fontSize: '1.2rem', color: '#2c2523' }}>Order #{order.orderId || order.id}</h2>
          <p style={{ color: '#666' }}>Status: <strong>{order.status || 'PROCESSING'}</strong></p>
          <p style={{ color: '#666' }}>Total: ₹{Number(order.totalAmount || 0).toLocaleString('en-IN')}</p>
        </div>
      )}
    </main>
  );
}