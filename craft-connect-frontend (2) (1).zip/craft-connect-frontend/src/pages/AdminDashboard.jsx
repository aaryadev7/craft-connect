
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('Overview');
  const [artisans, setArtisans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  async function loadArtisans() {
    setLoading(true);
    setError('');

    try {
      const data = await apiRequest('/api/admin/artisans/pending');
      setArtisans(
        Array.isArray(data)
          ? data
          : data?.content ?? data?.artisans ?? []
      );
    } catch (err) {
      setError(err.message || 'Could not load pending artisans.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (activeTab === 'Artisan Verification') {
      loadArtisans();
    }
  }, [activeTab]);

  async function reviewArtisan(artisanId, status) {
    try {
      await apiRequest(
        `/api/admin/artisans/${artisanId}/verification`,
        {
          method: 'PUT',
          body: JSON.stringify({ status }),
        }
      );

      setArtisans((current) =>
        current.filter(
          (artisan) =>
            (artisan.artisanId ?? artisan.id) !== artisanId
        )
      );

      setNotice(
        status === 'APPROVED'
          ? 'Artisan approved successfully.'
          : 'Artisan rejected.'
      );
      setError('');
    } catch (err) {
      setError(err.message || 'Unable to update artisan verification.');
    }
  }

  function logout() {
    localStorage.removeItem('craft_connect_token');
    localStorage.removeItem('craft_connect_role');
    window.location.href = '/admin/login';
  }

  const menu = [
    { name: 'Overview', icon: '▦' },
    { name: 'Artisan Verification', icon: '✳' },
    { name: 'Products', icon: '◇' },
    { name: 'Orders', icon: '□' },
  ];

  return (
    <main className="admin-shell">
      <aside className="admin-sidebar">
        <Link to="/" className="admin-brand">
          <span className="admin-brand-mark">C</span>
          <span>Craft Connect<small>ADMIN CONSOLE</small></span>
        </Link>

        <p className="admin-menu-label">WORKSPACE</p>

        <nav className="admin-menu">
          {menu.map((item) => (
            <button
              key={item.name}
              type="button"
              className={
                activeTab === item.name
                  ? 'admin-menu-item active'
                  : 'admin-menu-item'
              }
              onClick={() => {
                setActiveTab(item.name);
                setNotice('');
                setError('');
              }}
            >
              <span>{item.icon}</span>
              {item.name}
              {item.name === 'Artisan Verification' && (
                <span className="admin-menu-arrow">›</span>
              )}
            </button>
          ))}
        </nav>

        <div className="admin-sidebar-bottom">
          <div className="admin-profile">
            <div className="admin-avatar">A</div>
            <div>
              <strong>Administrator</strong>
              <small>Marketplace manager</small>
            </div>
          </div>

          <button
            type="button"
            className="admin-logout"
            onClick={logout}
          >
            ↪ Sign out
          </button>
        </div>
      </aside>

      <section className="admin-main">
        <header className="admin-topbar">
          <div>
            <p className="admin-breadcrumb">Workspace / {activeTab}</p>
            <h1>{activeTab}</h1>
          </div>

          <Link to="/" className="admin-view-site">
            View marketplace ↗
          </Link>
        </header>

        <div className="admin-content">
          {notice && (
            <div className="admin-notice" role="status">
              {notice}
              <button onClick={() => setNotice('')} aria-label="Dismiss">
                ×
              </button>
            </div>
          )}

          {error && (
            <div className="admin-error" role="alert">
              {error}
            </div>
          )}

          {activeTab === 'Overview' && (
            <>
              <div className="admin-welcome">
                <div>
                  <p className="admin-eyebrow">YOUR MARKETPLACE AT A GLANCE</p>
                  <h2>Welcome back, Admin <span>✳</span></h2>
                  <p>Here's what's happening with your craft community.</p>
                </div>
                <div className="admin-welcome-icon">✿</div>
              </div>

              <div className="admin-stat-grid">
                <article className="admin-stat-card">
                  <span className="admin-stat-icon purple">♙</span>
                  <p>Pending verifications</p>
                  <h3>—</h3>
                  <small>Review artisan applications</small>
                </article>

                <article className="admin-stat-card">
                  <span className="admin-stat-icon peach">◇</span>
                  <p>Marketplace products</p>
                  <h3>—</h3>
                  <small>Product catalogue</small>
                </article>

                <article className="admin-stat-card">
                  <span className="admin-stat-icon green">□</span>
                  <p>Total orders</p>
                  <h3>—</h3>
                  <small>Order management</small>
                </article>

                <article className="admin-stat-card">
                  <span className="admin-stat-icon yellow">♡</span>
                  <p>Community members</p>
                  <h3>—</h3>
                  <small>Artisans and customers</small>
                </article>
              </div>

              <div className="admin-panel">
                <div className="admin-panel-heading">
                  <div>
                    <h2>Artisan verification</h2>
                    <p>Review applications before artisans join the marketplace.</p>
                  </div>
                  <button
                    className="admin-outline-button"
                    onClick={() => setActiveTab('Artisan Verification')}
                  >
                    Review applications →
                  </button>
                </div>

                <div className="admin-empty">
                  <span>✳</span>
                  <h3>Keep the marketplace authentic</h3>
                  <p>Verify artisan profiles to help customers discover genuine makers.</p>
                </div>
              </div>

              <div className="admin-panel">
                <div className="admin-panel-heading">
                  <div>
                    <h2>Marketplace management</h2>
                    <p>Use the workspace menu to review artisans and manage the platform.</p>
                  </div>
                </div>
                <div className="admin-quick-links">
                  <button onClick={() => setActiveTab('Products')}>
                    <span>◇</span>
                    <strong>Product moderation</strong>
                    <small>Review marketplace listings</small>
                  </button>
                  <button onClick={() => setActiveTab('Orders')}>
                    <span>□</span>
                    <strong>Order management</strong>
                    <small>View order workflow</small>
                  </button>
                </div>
              </div>
            </>
          )}

          {activeTab === 'Artisan Verification' && (
            <div className="admin-panel">
              <div className="admin-panel-heading">
                <div>
                  <h2>Pending artisan applications</h2>
                  <p>Review applications and approve or reject them.</p>
                </div>
                <button
                  className="admin-outline-button"
                  onClick={loadArtisans}
                  disabled={loading}
                >
                  {loading ? 'Loading...' : '↻ Refresh'}
                </button>
              </div>

              {loading && (
                <div className="admin-empty">Loading applications...</div>
              )}

              {!loading && !error && artisans.length === 0 && (
                <div className="admin-empty">
                  <span>✓</span>
                  <h3>You're all caught up</h3>
                  <p>No pending applications were returned by the server.</p>
                </div>
              )}

              {!loading && artisans.length > 0 && (
                <div className="admin-table-wrap">
                  <table className="admin-table">
                    <thead>
                      <tr>
                        <th>Artisan</th>
                        <th>Email</th>
                        <th>Verification</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {artisans.map((artisan) => {
                        const id = artisan.artisanId ?? artisan.id;

                        return (
                          <tr key={id}>
                            <td>
                              <div className="admin-artisan-cell">
                                <div className="admin-avatar">
                                  {(artisan.name || artisan.fullName || 'A')
                                    .charAt(0)
                                    .toUpperCase()}
                                </div>
                                <strong>
                                  {artisan.name ||
                                    artisan.fullName ||
                                    artisan.businessName ||
                                    `Artisan #${id}`}
                                </strong>
                              </div>
                            </td>
                            <td>{artisan.email || '—'}</td>
                            <td>
                              <span className="admin-pending-badge">
                                Pending
                              </span>
                            </td>
                            <td>
                              <div className="admin-action-group">
                                <button
                                  className="admin-approve"
                                  onClick={() => reviewArtisan(id, 'APPROVED')}
                                >
                                  Approve
                                </button>
                                <button
                                  className="admin-reject"
                                  onClick={() => reviewArtisan(id, 'REJECTED')}
                                >
                                  Reject
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === 'Products' && (
            <div className="admin-panel">
              <div className="admin-panel-heading">
                <div>
                  <h2>Product moderation</h2>
                  <p>Keep listings clear, appropriate, and relevant to handmade crafts.</p>
                </div>
              </div>
              <div className="admin-empty">
                <span>◇</span>
                <h3>Product moderation UI</h3>
                <p>Connect a product-management endpoint to show and review live listings here.</p>
              </div>
            </div>
          )}

          {activeTab === 'Orders' && (
            <div className="admin-panel">
              <div className="admin-panel-heading">
                <div>
                  <h2>Order management</h2>
                  <p>Monitor orders and their payment and fulfilment statuses.</p>
                </div>
              </div>
              <div className="admin-empty">
                <span>□</span>
                <h3>Order overview</h3>
                <p>Order statistics will appear here when a suitable admin API is connected.</p>
              </div>
            </div>
          )}
        </div>

        <footer className="admin-footer">
          Craft Connect Admin · Manage with care.
        </footer>
      </section>
    </main>
  );
}
