
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function ArtisanRegister() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    craftCategory: '',
    craftDescription: '',
  });

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((previous) => ({ ...previous, [name]: value }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');

    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    if (form.password.length < 8) {
      setError('Password must contain at least 8 characters.');
      return;
    }

    if (!/^\d{10}$/.test(form.phone.trim())) {
      setError('Enter a valid 10-digit phone number.');
      return;
    }

    setLoading(true);

    try {
      await apiRequest('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({
          fullName: form.fullName.trim(),
          email: form.email.trim(),
          phone: form.phone.trim(),
          password: form.password,
          role: 'ARTISAN',
          craftCategory: form.craftCategory,
          craftDescription: form.craftDescription.trim(),
        }),
      });

      navigate('/artisan/login', {
        replace: true,
        state: {
          message: 'Registration submitted. Please sign in when your account is approved.',
        },
      });
    } catch (err) {
      setError(
        err.message ||
        'Registration failed. Please check your details and try again.'
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="auth-page">
      <section className="auth-card">
        <Link to="/" className="back-link">
          ← Craft Connect
        </Link>

        <p className="eyebrow">ARTISAN PORTAL</p>
        <h1>Share your craft with the world.</h1>

        <p className="auth-description">
          Create your artisan account and introduce customers to your handmade work.
        </p>

        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="artisan-name">Full name</label>
            <input
              id="artisan-name"
              name="fullName"
              value={form.fullName}
              onChange={handleChange}
              autoComplete="name"
              placeholder="Enter your full name"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="artisan-email">Email address</label>
            <input
              id="artisan-email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              autoComplete="email"
              placeholder="you@example.com"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="artisan-phone">Phone number</label>
            <input
              id="artisan-phone"
              name="phone"
              type="tel"
              value={form.phone}
              onChange={handleChange}
              autoComplete="tel"
              inputMode="numeric"
              pattern="[0-9]{10}"
              maxLength={10}
              placeholder="10-digit phone number"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="artisan-category">Craft category</label>
            <select
              id="artisan-category"
              name="craftCategory"
              value={form.craftCategory}
              onChange={handleChange}
              required
            >
              <option value="">Select your craft</option>
              <option value="Painting">Painting and art</option>
              <option value="Pottery">Pottery and ceramics</option>
              <option value="Jewellery">Handmade jewellery</option>
              <option value="Textiles">Textiles and embroidery</option>
              <option value="Woodwork">Woodwork</option>
              <option value="Home Decor">Home decor</option>
              <option value="Other">Other crafts</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="artisan-description">About your craft</label>
            <textarea
              id="artisan-description"
              name="craftDescription"
              value={form.craftDescription}
              onChange={handleChange}
              rows={3}
              placeholder="Describe your craft and handmade products"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="artisan-password">Password</label>
            <input
              id="artisan-password"
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              autoComplete="new-password"
              minLength={8}
              placeholder="At least 8 characters"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="artisan-confirm-password">
              Confirm password
            </label>
            <input
              id="artisan-confirm-password"
              name="confirmPassword"
              type="password"
              value={form.confirmPassword}
              onChange={handleChange}
              autoComplete="new-password"
              placeholder="Enter password again"
              required
            />
          </div>

          {error && (
            <p className="login-error" role="alert">
              {error}
            </p>
          )}

          <button
            type="submit"
            className="primary-button"
            disabled={loading}
          >
            {loading ? 'Submitting...' : 'Register as Artisan'}
          </button>
        </form>

        <p className="auth-footer">
          Already have an account?{' '}
          <Link to="/artisan/login">Sign in</Link>
        </p>
      </section>
    </main>
  );
}
