import { useEffect, useState, useCallback, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function CartPage() {
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState(null);
  
  // Profile dropdown state
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileDropdownRef = useRef(null);
  const navigate = useNavigate();

  // Load cart data from backend
  const loadCart = useCallback(async () => {
    try {
      setError('');
      const data = await apiRequest('/api/cart/details');
      setCart(data);
    } catch (err) {
      setError(err.message || 'Unable to load your cart.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCart();
  }, [loadCart]);

  // Close profile dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(event.target)) {
        setIsProfileOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Quantity Change Handler
  async function changeQuantity(item, quantity) {
    if (quantity < 1) {
      await removeItem(item);
      return;
    }
    setBusyId(item.cartItemId);
    try {
      await apiRequest(`/api/cart/items/${item.cartItemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantity }),
      });
      await loadCart();
    } catch (err) {
      setError(err.message || 'Unable to update quantity.');
    } finally {
      setBusyId(null);
    }
  }

  // Remove Item Handler
  async function removeItem(item) {
    setBusyId(item.cartItemId);
    try {
      await apiRequest(`/api/cart/items/${item.cartItemId}`, {
        method: 'DELETE',
      });
      await loadCart();
    } catch (err) {
      setError(err.message || 'Unable to remove item.');
    } finally {
      setBusyId(null);
    }
  }

  function logout() {
    localStorage.removeItem('craft_connect_token');
    localStorage.removeItem('craft_connect_role');
    window.location.href = '/customer/login';
  }

  const items = cart?.items ?? [];
  const total = Number(cart?.totalAmount ?? 0);
  const cartCount = items.reduce((sum, item) => sum + (item.quantity || 1), 0);

  return (
    <main className="shop-page">
      <header className="shop-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" className="shop-brand">Craft Connect<span>.</span></Link>

        <nav style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
          <Link to="/customer/dashboard" className="shop-back">← Continue shopping</Link>

          {/* Profile Dropdown Menu */}
          <div className="profile-menu-container" ref={profileDropdownRef} style={{ position: 'relative' }}>
            <button
              type="button"
              className="profile-icon-btn"
              onClick={() => setIsProfileOpen((prev) => !prev)}
              aria-label="User Account Menu"
              style={{
                background: '#f4efe8',
                border: '1px solid #dcd6cd',
                borderRadius: '50%',
                width: '40px',
                height: '40px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.1rem'
              }}
            >
              👤
            </button>

            {isProfileOpen && (
              <div
                className="profile-dropdown-menu"
                style={{
                  position: 'absolute',
                  right: 0,
                  top: '120%',
                  width: '210px',
                  backgroundColor: '#ffffff',
                  border: '1px solid #e5e0d8',
                  borderRadius: '12px',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                  zIndex: 1000,
                  padding: '0.5rem 0',
                  display: 'flex',
                  flexDirection: 'column'
                }}
              >
                <div style={{ padding: '0.5rem 1rem', borderBottom: '1px solid #f0ebe1' }}>
                  <strong style={{ fontSize: '0.75rem', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    My Account
                  </strong>
                </div>

                {/* Cart Option */}
                <Link
                  to="/customer/cart"
                  onClick={() => setIsProfileOpen(false)}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '0.65rem 1rem',
                    color: '#2c2523',
                    textDecoration: 'none',
                    fontSize: '0.95rem'
                  }}
                >
                  <span>🛒 Cart</span>
                  {cartCount > 0 && (
                    <span
                      style={{
                        background: '#8c6d53',
                        color: '#ffffff',
                        borderRadius: '10px',
                        padding: '2px 8px',
                        fontSize: '0.75rem',
                        fontWeight: 'bold'
                      }}
                    >
                      {cartCount}
                    </span>
                  )}
                </Link>

                {/* My Orders Option */}
                <Link
                  to="/customer/orders"
                  onClick={() => setIsProfileOpen(false)}
                  style={{
                    padding: '0.65rem 1rem',
                    color: '#2c2523',
                    textDecoration: 'none',
                    fontSize: '0.95rem'
                  }}
                >
                  📦 My Orders
                </Link>

                {/* Track Order Option */}
                <Link
                  to="/customer/track-order"
                  onClick={() => setIsProfileOpen(false)}
                  style={{
                    padding: '0.65rem 1rem',
                    color: '#2c2523',
                    textDecoration: 'none',
                    fontSize: '0.95rem'
                  }}
                >
                  📍 Track Order
                </Link>

                <hr style={{ margin: '0.4rem 0', border: 'none', borderTop: '1px solid #f0ebe1' }} />

                {/* Sign Out Option */}
                <button
                  type="button"
                  onClick={() => {
                    setIsProfileOpen(false);
                    logout();
                  }}
                  style={{
                    background: 'none',
                    border: 'none',
                    textAlign: 'left',
                    padding: '0.65rem 1rem',
                    color: '#d9534f',
                    cursor: 'pointer',
                    width: '100%',
                    fontSize: '0.95rem',
                    fontWeight: '500'
                  }}
                >
                  🚪 Sign out
                </button>
              </div>
            )}
          </div>
        </nav>
      </header>

      <section className="shop-content">
        <p className="shop-eyebrow">YOUR SELECTION</p>
        <h1>Your shopping cart</h1>
        <p className="shop-muted">Handpicked creations, ready for you.</p>

        {loading && <p className="shop-message">Loading your cart...</p>}

        {error && <p className="shop-error" role="alert">{error}</p>}

        {!loading && !error && items.length === 0 && (
          <div className="shop-empty">
            <span>♡</span>
            <h2>Your cart is waiting for something special.</h2>
            <p>Explore handmade creations from our artisan community.</p>
            <Link to="/customer/dashboard" className="shop-primary">
              Explore marketplace →
            </Link>
          </div>
        )}

        {!loading && items.length > 0 && (
          <div className="shop-layout">
            <div className="shop-items">
              {items.map((item) => {
                const note = item.customizationNote || item.notes;
                return (
                  <article className="shop-item" key={item.cartItemId}>
                    <div className="shop-item-art">
                      {item.productImage ? (
                        <img
                          src={item.productImage}
                          alt={item.productName}
                          style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '8px' }}
                        />
                      ) : (
                        '✿'
                      )}
                    </div>
                    <div className="shop-item-info">
                      <span>{item.sku || 'HANDCRAFTED'}</span>
                      <h3>{item.productName}</h3>
                      <p>{item.variantName || 'Handmade creation'}</p>
                      
                      {/* Display Customization Note in Cart */}
                      {note && (
                        <div style={{ marginTop: '4px', marginBottom: '4px', fontSize: '0.85rem', color: '#8c6d53', fontStyle: 'italic' }}>
                          ✏️ Customization: "{note}"
                        </div>
                      )}

                      <strong>₹{Number(item.unitPrice).toLocaleString('en-IN')}</strong>
                      <div className="shop-quantity">
                        <button
                          disabled={busyId === item.cartItemId}
                          onClick={() => changeQuantity(item, item.quantity - 1)}
                          aria-label="Decrease quantity"
                        >−</button>
                        <span>{item.quantity}</span>
                        <button
                          disabled={busyId === item.cartItemId}
                          onClick={() => changeQuantity(item, item.quantity + 1)}
                          aria-label="Increase quantity"
                        >+</button>
                      </div>
                    </div>
                    <div className="shop-item-end">
                      <strong>₹{Number(item.subtotal).toLocaleString('en-IN')}</strong>
                      <button
                        className="shop-remove"
                        disabled={busyId === item.cartItemId}
                        onClick={() => removeItem(item)}
                      >Remove</button>
                    </div>
                  </article>
                );
              })}
            </div>

            <aside className="shop-summary">
              <h2>Order summary</h2>
              <div><span>Items ({items.length})</span><span>₹{total.toLocaleString('en-IN')}</span></div>
              <div><span>Shipping</span><span>Calculated later</span></div>
              <hr />
              <div className="shop-total"><strong>Subtotal</strong><strong>₹{total.toLocaleString('en-IN')}</strong></div>
              <p>Shipping and final charges will be confirmed at checkout.</p>
              <button
                className="shop-primary shop-full"
                onClick={() => navigate('/customer/checkout')}
              >
                Continue to checkout →
              </button>
              <small>♡ Supporting independent artisans</small>
            </aside>
          </div>
        )}
      </section>
    </main>
  );
}