
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function AddReel() {
  const navigate = useNavigate();

  const [videoUrl, setVideoUrl] = useState('');
  const [caption, setCaption] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleReelSubmit(event) {
    event.preventDefault();
    setError('');
    setMessage('');

    if (!localStorage.getItem('craft_connect_token')) {
      setError('Your session has expired. Please sign in again.');
      return;
    }

    if (!videoUrl.trim()) {
      setError('Please enter a valid video URL.');
      return;
    }

    setLoading(true);

    try {
      await apiRequest('/api/reels', {
        method: 'POST',
        body: JSON.stringify({
          videoUrl: videoUrl.trim(),
          caption: caption.trim(),
        }),
      });

      setMessage('Reel published successfully!');
      setVideoUrl('');
      setCaption('');
    } catch (err) {
      setError(err.message || 'Unable to publish the reel.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{
      maxWidth: '650px',
      margin: '40px auto',
      padding: '24px',
      fontFamily: 'Arial, sans-serif',
      color: '#30251f',
    }}>
      <Link
        to="/artisan/dashboard"
        style={{
          color: '#70452f',
          textDecoration: 'none',
          fontWeight: 600,
        }}
      >
        ← Back to dashboard
      </Link>

      <section style={{
        marginTop: '24px',
        padding: '28px',
        background: '#fff',
        border: '1px solid #eee4da',
        borderRadius: '14px',
      }}>
        <h1>Upload a Craft Reel</h1>
        <p>Share a video showcasing your craft or creative process.</p>

        {error && (
          <p role="alert" style={{ color: '#b42318' }}>
            {error}
          </p>
        )}

        {message && (
          <p role="status" style={{ color: '#217346' }}>
            {message}
          </p>
        )}

        <form onSubmit={handleReelSubmit}>
          <div style={{ marginBottom: '20px' }}>
            <label
              htmlFor="videoUrl"
              style={{ display: 'block', marginBottom: '8px' }}
            >
              Video URL *
            </label>

            <input
              id="videoUrl"
              type="url"
              value={videoUrl}
              onChange={(event) => setVideoUrl(event.target.value)}
              placeholder="https://res.cloudinary.com/.../video.mp4"
              required
              style={{
                boxSizing: 'border-box',
                width: '100%',
                padding: '12px',
                border: '1px solid #d9cec4',
                borderRadius: '8px',
              }}
            />
          </div>

          {videoUrl && (
            <video
              src={videoUrl}
              controls
              style={{
                width: '100%',
                maxHeight: '300px',
                marginBottom: '20px',
                borderRadius: '8px',
                background: '#f5f5f5',
              }}
            />
          )}

          <div style={{ marginBottom: '20px' }}>
            <label
              htmlFor="caption"
              style={{ display: 'block', marginBottom: '8px' }}
            >
              Caption
            </label>

            <textarea
              id="caption"
              value={caption}
              onChange={(event) => setCaption(event.target.value)}
              placeholder="Describe your craft..."
              rows={4}
              maxLength={1000}
              style={{
                boxSizing: 'border-box',
                width: '100%',
                padding: '12px',
                border: '1px solid #d9cec4',
                borderRadius: '8px',
                resize: 'vertical',
              }}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '13px',
              border: 'none',
              borderRadius: '8px',
              background: '#70452f',
              color: '#fff',
              fontWeight: 700,
              cursor: loading ? 'wait' : 'pointer',
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? 'Publishing...' : 'Publish Reel'}
          </button>
        </form>

        <button
          type="button"
          onClick={() => navigate('/artisan/dashboard')}
          style={{
            marginTop: '16px',
            padding: '8px 0',
            border: 'none',
            background: 'transparent',
            color: '#70452f',
            cursor: 'pointer',
          }}
        >
          Cancel
        </button>
      </section>
    </main>
  );
}
