
import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function CheckoutPage() {
  const navigate = useNavigate();

  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [fullName, setFullName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [pincode, setPincode] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    async function loadCart() {
      try {
        setLoading(true);

        let data;

        try {
          data = await apiRequest('/api/cart/details');
        } catch {
          data = await apiRequest('/api/cart');
        }

        const items =
          data?.items ??
          data?.cartItems ??
          (Array.isArray(data) ? data : []);

        setCartItems(items);

        if (items.length === 0) {
          setError('Your cart is empty. Please add items before checking out.');
        }
      } catch (err) {
        setError(err.message || 'Unable to fetch cart details.');
      } finally {
        setLoading(false);
      }
    }

    loadCart();
  }, []);

  const totalAmount = cartItems.reduce((total, item) => {
    const price =
      item.unitPrice ??
      item.price ??
      item.product?.price ??
      item.variant?.price ??
      0;

    return total + Number(price) * Number(item.quantity ?? 1);
  }, 0);

  function loadRazorpayScript() {
    return new Promise((resolve) => {
      if (window.Razorpay) {
        resolve(true);
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');

    if (cartItems.length === 0) {
      setError('Your cart is empty.');
      return;
    }

    setBusy(true);

    try {
      const scriptLoaded = await loadRazorpayScript();

      if (!scriptLoaded) {
        throw new Error('Razorpay SDK failed to load. Check your internet connection.');
      }

      // Step 1: Create the Craft Connect order.
      const orderData = await apiRequest('/api/orders', {
        method: 'POST',
      });

      const craftOrderId = orderData?.orderId;

      if (!craftOrderId) {
        throw new Error('The backend did not return an order ID.');
      }

      // Step 2: Create the Razorpay order using the backend endpoint.
      const paymentData = await apiRequest(
        `/api/payments/create-order/${craftOrderId}`,
        { method: 'POST' }
      );

      const keyId = paymentData?.keyId;
      const razorpayOrderId = paymentData?.razorpayOrderId;
      const amount = paymentData?.amount;
      const currency = paymentData?.currency || 'INR';

      if (
        !keyId ||
        !razorpayOrderId ||
        !Number.isFinite(Number(amount)) ||
        Number(amount) <= 0 ||
        keyId.includes('YourRazorpayKeyHere')
      ) {
        throw new Error(
          'Payment details are missing or invalid. Check the backend response and Razorpay configuration.'
        );
      }

      const fullShippingAddress =
        `${fullName}, ${address}, ${city} - ${pincode} (Ph: ${phone})`;

      // Step 3: Open Razorpay Checkout.
      const options = {
        key: keyId,
        amount: Number(amount),
        currency,
        name: 'Craft Connect',
        description: 'Handmade Order Payment',
        order_id: razorpayOrderId,

        prefill: {
          name: fullName || localStorage.getItem('craft_connect_name') || 'Customer',
          email: localStorage.getItem('craft_connect_email') || '',
          contact: phone,
        },

        theme: {
          color: '#8c6d53',
        },

        handler: async function (response) {
          try {
            // Step 4: Verify payment with the backend.
            await apiRequest('/api/payments/verify', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                craftOrderId,
                razorpayOrderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              }),
            });

            navigate('/customer/order-confirmation', {
              state: {
                orderId: craftOrderId,
                totalAmount,
                paymentStatus: 'PAID',
                address: fullShippingAddress,
              },
            });
          } catch (verifyError) {
            setError(
              verifyError.message || 'Payment verification failed.'
            );
          }
        },

        modal: {
          ondismiss: () => {
            setError('Payment cancelled. Your order may remain pending.');
          },
        },
      };

      const paymentObject = new window.Razorpay(options);

      paymentObject.on('payment.failed', (response) => {
        setError(
          response?.error?.description ||
          'Payment failed. Please try again.'
        );
      });

      paymentObject.open();
    } catch (err) {
      console.error('Checkout error:', err);
      setError(err.message || 'Unable to place order. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="shop-page">
      <header className="shop-header">
        <Link to="/" className="shop-brand">
          craft<span>connect</span>
        </Link>

        <Link to="/customer/dashboard" className="shop-back">
          ← Return to Marketplace
        </Link>
      </header>

      <section className="shop-content">
        <span className="shop-eyebrow">FINAL STEP</span>

        <h1 style={{ margin: '0.2rem 0 1.5rem', color: '#2c2523' }}>
          Shipping &amp; Checkout
        </h1>

        {loading ? (
          <div className="cc-state">
            <span className="cc-loader" />
            <p>Preparing your checkout summary...</p>
          </div>
        ) : error && cartItems.length === 0 ? (
          <div className="shop-empty">
            <p style={{ color: '#d9534f' }}>{error}</p>

            <Link
              to="/customer/dashboard"
              className="cc-primary-button"
              style={{ marginTop: '1rem' }}
            >
              Explore Creations ↗
            </Link>
          </div>
        ) : (
          <div className="shop-layout">
            <div>
              <form className="checkout-card" onSubmit={handleSubmit}>
                <h2
                  style={{
                    fontSize: '1.2rem',
                    margin: '0 0 1.2rem',
                    color: '#2c2523',
                  }}
                >
                  Delivery Address
                </h2>

                {error && <div className="shop-error">{error}</div>}

                <label>
                  Full Name
                  <input
                    type="text"
                    required
                    placeholder="e.g. Aarya Lohar"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                  />
                </label>

                <label>
                  Street Address
                  <textarea
                    rows={3}
                    required
                    placeholder="Flat/House No., Building Name, Street"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                  />
                </label>

                <div className="checkout-row">
                  <label>
                    City
                    <input
                      type="text"
                      required
                      placeholder="e.g. Mumbai"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                    />
                  </label>

                  <label>
                    PIN Code
                    <input
                      type="text"
                      required
                      placeholder="e.g. 400053"
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value)}
                    />
                  </label>
                </div>

                <label>
                  Phone Number
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9876543210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </label>

                <div
                  className="checkout-note"
                  style={{ marginTop: '1rem' }}
                >
                  <span>🔒</span>
                  <span>Payments are secured via Razorpay.</span>
                </div>

                <button
                  type="submit"
                  className="cc-primary-button shop-full"
                  disabled={busy || cartItems.length === 0}
                  style={{ padding: '1rem' }}
                >
                  {busy
                    ? 'Initiating Payment...'
                    : `Proceed to Pay ₹${totalAmount.toLocaleString('en-IN', {
                        minimumFractionDigits: 2,
                      })} ↗`}
                </button>
              </form>
            </div>

            <aside className="shop-summary">
              <h2>Order Summary</h2>

              <div
                className="shop-items"
                style={{ marginBottom: '1.2rem' }}
              >
                {cartItems.map((item, index) => {
                  const name =
                    item.productName ||
                    item.product?.name ||
                    item.name ||
                    'Handcrafted Creation';

                  const price =
                    item.unitPrice ??
                    item.price ??
                    item.product?.price ??
                    item.variant?.price ??
                    0;

                  const quantity = item.quantity ?? 1;
                  const note = item.customizationNote || item.notes;

                  return (
                    <div
                      key={item.cartItemId ?? index}
                      style={{
                        borderBottom: '1px solid #f0ebe1',
                        paddingBottom: '0.8rem',
                      }}
                    >
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          fontSize: '0.9rem',
                        }}
                      >
                        <span style={{ fontWeight: '500', color: '#2c2523' }}>
                          {name} × {quantity}
                        </span>

                        <span style={{ fontWeight: '600' }}>
                          ₹{(
                            Number(price) * Number(quantity)
                          ).toLocaleString('en-IN', {
                            minimumFractionDigits: 2,
                          })}
                        </span>
                      </div>

                      {note && (
                        <small
                          style={{
                            color: '#8c6d53',
                            fontStyle: 'italic',
                            display: 'block',
                            marginTop: '2px',
                          }}
                        >
                          ✏️ "{note}"
                        </small>
                      )}
                    </div>
                  );
                })}
              </div>

              <div>
                <span>Items Subtotal</span>
                <strong>
                  ₹{totalAmount.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                  })}
                </strong>
              </div>

              <div>
                <span>Delivery Charge</span>
                <strong style={{ color: '#2e7d32' }}>FREE</strong>
              </div>

              <hr />

              <div className="shop-total">
                <span>Total Amount</span>
                <span>
                  ₹{totalAmount.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                  })}
                </span>
              </div>
            </aside>
          </div>
        )}
      </section>
    </main>
  );
}
