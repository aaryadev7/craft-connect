import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function ArtisanStorefrontPage() {
  const { artisanId } = useParams();
  const [artisan, setArtisan] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function loadStorefront() {
      try {
        setLoading(true);
        setError('');

        const [artisanData, productData] = await Promise.all([
          apiRequest(`/api/artisans/${artisanId}`).catch(() => null),
          apiRequest(`/api/products/artisan/${artisanId}`).catch(() => []),
        ]);

        setArtisan(artisanData);

        const list = Array.isArray(productData)
          ? productData
          : productData?.content ?? productData?.products ?? [];

        setProducts(list.filter((p) => !p.deletedAt && p.status !== 'INACTIVE'));
      } catch (err) {
        setError(err.message || 'Unable to load artisan storefront.');
      } finally {
        setLoading(false);
      }
    }

    if (artisanId) {
      loadStorefront();
    }
  }, [artisanId]);

  return (
    <main style={{ maxWidth: '1100px', margin: '0 auto', padding: '2rem 5%', fontFamily: 'sans-serif' }}>
      <header style={{ marginBottom: '2rem' }}>
        <Link to="/customer/dashboard" style={{ textDecoration: 'none', color: '#8c6d53', fontWeight: 'bold' }}>
          ← Back to Marketplace
        </Link>
      </header>

      {loading && (
        <div style={{ textAlign: 'center', padding: '3rem 0', color: '#666' }}>
          <p>Loading artisan store...</p>
        </div>
      )}

      {error && (
        <div style={{ padding: '1rem', background: '#fdf2f2', color: '#c53030', borderRadius: '8px', marginBottom: '1.5rem' }}>
          {error}
        </div>
      )}

      {!loading && !error && (
        <>
          <section style={{
            background: '#faf8f5',
            border: '1px solid #e8e2d8',
            borderRadius: '16px',
            padding: '2.5rem',
            marginBottom: '3rem',
            display: 'flex',
            alignItems: 'center',
            gap: '2rem',
            flexWrap: 'wrap'
          }}>
            <div style={{
              width: '90px',
              height: '90px',
              borderRadius: '50%',
              backgroundColor: '#8c6d53',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '2.5rem',
              fontWeight: 'bold',
              flexShrink: 0
            }}>
              {(artisan?.artisanName || artisan?.shopName || artisan?.name || 'A')[0].toUpperCase()}
            </div>

            <div style={{ flex: 1, minWidth: '250px' }}>
              <span style={{ fontSize: '0.8rem', color: '#8c6d53', fontWeight: 'bold', letterSpacing: '1px' }}>
                VERIFIED ARTISAN
              </span>
              <h1 style={{ margin: '0.3rem 0', color: '#2c2523', fontSize: '2rem' }}>
                {artisan?.artisanName || artisan?.shopName || artisan?.name || 'Local Artisan Store'}
              </h1>
              <p style={{ color: '#666', margin: '0.3rem 0 0.8rem', maxWidth: '600px', lineHeight: '1.5' }}>
                {artisan?.bio || artisan?.craftStory || 'Crafting authentic, high-quality handmade treasures with passion and care.'}
              </p>
              <div style={{ display: 'flex', gap: '1.5rem', fontSize: '0.9rem', color: '#888', flexWrap: 'wrap' }}>
                <span>📍 {artisan?.location || artisan?.city || 'India'}</span>
                <span>🛍️ {products.length} {products.length === 1 ? 'Creation' : 'Creations'}</span>
                {artisan?.yearsOfExperience && (
                  <span>✨ {artisan.yearsOfExperience} Years Experience</span>
                )}
              </div>
            </div>
          </section>

          <section>
            <h2 style={{ color: '#2c2523', marginBottom: '1.5rem', fontSize: '1.5rem' }}>Creations by this Artisan</h2>
            
            {products.length === 0 ? (
              <p style={{ color: '#888', fontStyle: 'italic' }}>No active listings currently available for this artisan.</p>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1.5rem' }}>
                {products.map((product) => {
                  const id = product.productId ?? product.id;
                  const name = product.productName || product.name || 'Handmade Creation';
                  const price = product.price ?? product.variants?.[0]?.price;
                  const image = product.imageUrl || product.imageURL;
                  const description = product.description || '';

                  return (
                    <div 
                      key={id} 
                      style={{ 
                        border: '1px solid #e5e0d8', 
                        borderRadius: '12px', 
                        overflow: 'hidden', 
                        backgroundColor: '#fff',
                        display: 'flex',
                        flexDirection: 'column',
                        boxShadow: '0 4px 12px rgba(0,0,0,0.03)'
                      }}
                    >
                      <div style={{ width: '100%', height: '200px', backgroundColor: '#f4efe8', position: 'relative' }}>
                        {image ? (
                          <img src={image} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        ) : (
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#8c6d53', fontWeight: '500' }}>
                            Handcrafted
                          </div>
                        )}
                      </div>
                      
                      <div style={{ padding: '1.2rem', display: 'flex', flexDirection: 'column', flex: 1, justifyContent: 'space-between' }}>
                        <div>
                          <h3 style={{ fontSize: '1.1rem', margin: '0 0 0.4rem', color: '#2c2523' }}>{name}</h3>
                          <p style={{ fontSize: '0.85rem', color: '#666', margin: '0 0 1rem', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                            {description}
                          </p>
                        </div>

                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto' }}>
                          <span style={{ fontWeight: 'bold', color: '#8c6d53', fontSize: '1.05rem' }}>
                            {price != null ? `₹${Number(price).toLocaleString('en-IN', { minimumFractionDigits: 2 })}` : 'Price on request'}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </>
      )}
    </main>
  );
}