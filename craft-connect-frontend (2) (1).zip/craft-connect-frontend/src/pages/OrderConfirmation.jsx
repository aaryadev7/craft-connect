
import { Link, useLocation } from 'react-router-dom';

export default function OrderConfirmation() {
  const { state } = useLocation();

  return (
    <main className="shop-page">
      <header className="shop-header">
        <Link to="/" className="shop-brand">Craft Connect<span>.</span></Link>
      </header>

      <section className="shop-content">
        <div className="shop-empty confirmation-card">
          <div className="confirmation-check">✓</div>
          <p className="shop-eyebrow">ORDER CREATED</p>
          <h1>Thank you for supporting handmade.</h1>
          <p>
            {state?.orderId
              ? `Your order reference is #${state.orderId}.`
              : 'Your order details will appear here after checkout.'}
          </p>

          {state?.totalAmount != null && (
            <h2>Order total: ₹{Number(state.totalAmount).toLocaleString('en-IN')}</h2>
          )}

          <p className="shop-muted">
            Payment status: {state?.paymentStatus || 'Awaiting confirmation'}
          </p>

          <Link to="/customer/dashboard" className="shop-primary">
            Return to marketplace →
          </Link>
        </div>
      </section>
    </main>
  );
}
