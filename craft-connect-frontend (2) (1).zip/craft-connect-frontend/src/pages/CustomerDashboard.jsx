
import { useEffect, useMemo, useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function CustomerDashboard() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState('featured');

  const [cartCount, setCartCount] = useState(0);
  const [cartItems, setCartItems] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cartLoading, setCartLoading] = useState(false);
  const [customizations, setCustomizations] = useState({});
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileDropdownRef = useRef(null);
  const navigate = useNavigate();
  const [addingId, setAddingId] = useState(null);
  const [notice, setNotice] = useState('');
  const [checkingOut, setCheckingOut] = useState(false);

  const [wishlist, setWishlist] = useState(() => {
    try {
      return JSON.parse(
        localStorage.getItem('craft_connect_wishlist') || '[]'
      );
    } catch {
      return [];
    }
  });

  useEffect(() => {
    function handleClickOutside(event) {
      if (
        profileDropdownRef.current &&
        !profileDropdownRef.current.contains(event.target)
      ) {
        setIsProfileOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () =>
      document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  async function fetchCart() {
    try {
      setCartLoading(true);

      let data;
      try {
        data = await apiRequest('/api/cart/details');
      } catch {
        data = await apiRequest('/api/cart').catch(() => []);
      }

      const items =
        data?.items ??
        data?.cartItems ??
        (Array.isArray(data) ? data : []);

      setCartItems(items);
      setCartCount(
        items.reduce((sum, item) => sum + (item.quantity || 1), 0)
      );
    } catch (err) {
      console.error('Could not load cart:', err);
    } finally {
      setCartLoading(false);
    }
  }

  useEffect(() => {
    async function loadInitialData() {
      try {
        const productData = await apiRequest('/api/products').catch(() => []);
        const list = Array.isArray(productData)
          ? productData
          : productData?.content ?? productData?.products ?? [];

        setProducts(
          Array.isArray(list)
            ? list.filter(
                (product) =>
                  product &&
                  !product.deletedAt &&
                  product.status !== 'INACTIVE'
              )
            : []
        );

        await fetchCart();
      } catch (err) {
        setError(err.message || 'Unable to load marketplace data.');
      } finally {
        setLoading(false);
      }
    }

    loadInitialData();
  }, []);

  const categories = useMemo(() => {
    const names = products
      .map((product) =>
        product?.categoryName || product?.category?.name
      )
      .filter(Boolean);

    return ['All', ...new Set(names)];
  }, [products]);

  const filteredProducts = useMemo(() => {
    let result = products.filter((product) => {
      const name = product.productName || product.name || '';
      const description = product.description || '';
      const categoryName =
        product.categoryName || product.category?.name || '';
      const artisanName =
        product.artisanName ||
        product.artisan?.shopName ||
        product.artisan?.name ||
        '';

      const matchesSearch =
        `${name} ${description} ${categoryName} ${artisanName}`
          .toLowerCase()
          .includes(search.trim().toLowerCase());

      const matchesCategory =
        category === 'All' || categoryName === category;

      return matchesSearch && matchesCategory;
    });

    if (sort === 'low') {
      result = [...result].sort(
        (a, b) => Number(a.price ?? Infinity) - Number(b.price ?? Infinity)
      );
    } else if (sort === 'high') {
      result = [...result].sort(
        (a, b) => Number(b.price ?? -Infinity) - Number(a.price ?? -Infinity)
      );
    } else if (sort === 'name') {
      result = [...result].sort((a, b) =>
        (a.productName || a.name || '').localeCompare(
          b.productName || b.name || ''
        )
      );
    }

    return result;
  }, [products, search, category, sort]);

  async function addToCart(product) {
    const rawProductId = product?.productId ?? product?.id;
    const productId = rawProductId != null ? Number(rawProductId) : null;

    const variant =
      product?.variants?.[0] ?? product?.productVariants?.[0];

    const rawVariantId =
      variant?.variantId ?? variant?.id ?? product?.variantId;

    const variantId =
      rawVariantId != null ? Number(rawVariantId) : null;

    const note = customizations[rawProductId] || '';

    const payload = {
      productId,
      quantity: 1,
      ...(variantId ? { variantId } : {}),
      customizationNote: note,
      notes: note,
    };

    setAddingId(rawProductId);

    try {
      await apiRequest('/api/cart/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      setNotice(
        `Added "${product.productName || product.name || 'Item'}" to your cart!`
      );

      setCustomizations((previous) => ({
        ...previous,
        [rawProductId]: '',
      }));

      await fetchCart();
    } catch (err) {
      console.error('Cart add error:', err);
      setNotice(`Cart Error: ${err.message || 'Could not add item.'}`);
    } finally {
      setAddingId(null);
    }
  }

  async function removeFromCart(cartItemId) {
    try {
      setCartLoading(true);

      await apiRequest(`/api/cart/items/${cartItemId}`, {
        method: 'DELETE',
      });

      await fetchCart();
      setNotice('Item removed from cart.');
    } catch (err) {
      setNotice(err.message || 'Could not remove item.');
    } finally {
      setCartLoading(false);
    }
  }

  function toggleWishlist(product) {
    const id = product.productId ?? product.id;

    setWishlist((previous) => {
      const exists = previous.some(
        (item) => (item.productId ?? item.id) === id
      );

      const updated = exists
        ? previous.filter((item) => (item.productId ?? item.id) !== id)
        : [...previous, product];

      localStorage.setItem(
        'craft_connect_wishlist',
        JSON.stringify(updated)
      );

      return updated;
    });

    setNotice('Wishlist updated.');
  }

  function loadRazorpayScript() {
    return new Promise((resolve) => {
      if (window.Razorpay) {
        resolve(true);
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  }

  async function handleRazorpayCheckout() {
    if (checkingOut) return;

    setCheckingOut(true);
    setNotice('');

    try {
      const scriptLoaded = await loadRazorpayScript();

      if (!scriptLoaded) {
        throw new Error('Razorpay SDK failed to load.');
      }

      // 1. Create the Craft Connect order.
      const orderData = await apiRequest('/api/orders', {
        method: 'POST',
      });

      const craftOrderId = orderData?.orderId;

      if (!craftOrderId) {
        throw new Error('Backend did not return an order ID.');
      }

      // 2. Create the Razorpay order using the correct backend endpoint.
      const paymentData = await apiRequest(
        `/api/payments/create-order/${craftOrderId}`,
        { method: 'POST' }
      );

      const keyId = paymentData?.keyId;
      const razorpayOrderId = paymentData?.razorpayOrderId;
      const amount = Number(paymentData?.amount);
      const currency = paymentData?.currency || 'INR';

      if (
        !keyId ||
        keyId.includes('YourRazorpayKeyHere') ||
        !razorpayOrderId ||
        !Number.isFinite(amount) ||
        amount <= 0
      ) {
        throw new Error(
          'Invalid Razorpay payment details. Check your backend credentials and response.'
        );
      }

      // 3. Open Razorpay Checkout.
      const options = {
        key: keyId,
        amount,
        currency,
        name: 'Craft Connect',
        description: 'Handmade Marketplace Purchase',
        order_id: razorpayOrderId,
        theme: { color: '#8c6d53' },

        handler: async (response) => {
          try {
            // 4. Verify payment on the backend.
            await apiRequest('/api/payments/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                craftOrderId,
                razorpayOrderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              }),
            });

            setNotice('Payment successful!');
            setIsCartOpen(false);
            setCartItems([]);
            setCartCount(0);

            navigate('/customer/order-confirmation', {
              state: { orderId: craftOrderId },
            });
          } catch (err) {
            setNotice(err.message || 'Payment verification failed.');
          }
        },

        modal: {
          ondismiss: () => {
            setNotice('Payment cancelled. Your order may remain pending.');
          },
        },
      };

      const paymentObject = new window.Razorpay(options);

      paymentObject.on('payment.failed', (response) => {
        setNotice(
          response?.error?.description || 'Payment failed. Please try again.'
        );
      });

      paymentObject.open();
    } catch (err) {
      console.error('Razorpay checkout error:', err);
      setNotice(err.message || 'Unable to initiate checkout.');
    } finally {
      setCheckingOut(false);
    }
  }

  function logout() {
    localStorage.removeItem('craft_connect_token');
    localStorage.removeItem('craft_connect_role');
    window.location.href = '/customer/login';
  }

  const cartSubtotal = cartItems.reduce((sum, item) => {
    const price =
      item?.unitPrice ??
      item?.price ??
      item?.product?.price ??
      item?.variant?.price ??
      0;

    return sum + Number(price) * Number(item?.quantity ?? 1);
  }, 0);

  return (
    <main className="cc-marketplace">
      <header className="cc-header">
        <Link to="/" className="cc-brand">
          <span className="cc-brand-mark">C</span>
          <span>
            craft<span className="cc-brand-accent">connect</span>
          </span>
        </Link>

        <nav
          className="cc-nav"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1.5rem',
          }}
        >
          <a href="#our-story">Our mission</a>

          <div
            className="cc-profile-menu-container"
            ref={profileDropdownRef}
            style={{ position: 'relative' }}
          >
            <button
              type="button"
              className="cc-profile-icon-btn"
              onClick={() => setIsProfileOpen((previous) => !previous)}
              aria-label="User Account Menu"
              style={{
                background: '#f4efe8',
                border: '1px solid #dcd6cd',
                borderRadius: '50%',
                width: '40px',
                height: '40px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.1rem',
              }}
            >
              👤
            </button>

            {isProfileOpen && (
              <div
                className="cc-profile-dropdown"
                style={{
                  position: 'absolute',
                  right: 0,
                  top: '120%',
                  width: '210px',
                  backgroundColor: '#fff',
                  border: '1px solid #e5e0d8',
                  borderRadius: '12px',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                  zIndex: 1000,
                  padding: '0.5rem 0',
                  display: 'flex',
                  flexDirection: 'column',
                }}
              >
                <div
                  style={{
                    padding: '0.5rem 1rem',
                    borderBottom: '1px solid #f0ebe1',
                  }}
                >
                  <strong
                    style={{
                      fontSize: '0.75rem',
                      color: '#888',
                      textTransform: 'uppercase',
                    }}
                  >
                    My Account
                  </strong>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setIsProfileOpen(false);
                    setIsCartOpen(true);
                    fetchCart();
                  }}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '0.65rem 1rem',
                    color: '#2c2523',
                    background: 'none',
                    border: 'none',
                    textAlign: 'left',
                    cursor: 'pointer',
                    width: '100%',
                    fontSize: '0.95rem',
                  }}
                >
                  <span>🛒 Cart</span>
                  {cartCount > 0 && (
                    <span
                      style={{
                        background: '#8c6d53',
                        color: '#fff',
                        borderRadius: '10px',
                        padding: '2px 8px',
                        fontSize: '0.75rem',
                      }}
                    >
                      {cartCount}
                    </span>
                  )}
                </button>

                <Link
                  to="/customer/track-order"
                  onClick={() => setIsProfileOpen(false)}
                  style={{
                    padding: '0.65rem 1rem',
                    color: '#2c2523',
                    textDecoration: 'none',
                    fontSize: '0.95rem',
                  }}
                >
                  📍 Track Order
                </Link>

                <hr
                  style={{
                    margin: '0.4rem 0',
                    border: 'none',
                    borderTop: '1px solid #f0ebe1',
                  }}
                />

                <button
                  type="button"
                  onClick={logout}
                  style={{
                    background: 'none',
                    border: 'none',
                    textAlign: 'left',
                    padding: '0.65rem 1rem',
                    color: '#d9534f',
                    cursor: 'pointer',
                    width: '100%',
                  }}
                >
                  🚪 Sign out
                </button>
              </div>
            )}
          </div>
        </nav>
      </header>

      {isCartOpen && (
        <div
          className="cc-cart-backdrop"
          onClick={() => setIsCartOpen(false)}
        >
          <div
            className="cc-cart-drawer"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="cc-cart-header">
              <h3>Your Cart ({cartCount})</h3>
              <button
                type="button"
                onClick={() => setIsCartOpen(false)}
              >
                ×
              </button>
            </div>

            <div className="cc-cart-body">
              {cartLoading ? (
                <div className="cc-state">
                  <span className="cc-loader" />
                  <p>Loading cart...</p>
                </div>
              ) : cartItems.length === 0 ? (
                <div className="cc-state">
                  <span>♡</span>
                  <p>Your cart is empty.</p>
                </div>
              ) : (
                <div className="cc-cart-items-list">
                  {cartItems.map((item, index) => {
                    const cartItemId = item.cartItemId ?? item.id;
                    const itemName =
                      item.productName ||
                      item.product?.name ||
                      item.name ||
                      'Handcrafted Item';
                    const itemPrice =
                      item.unitPrice ??
                      item.price ??
                      item.product?.price ??
                      item.variant?.price ??
                      0;
                    const itemQty = item.quantity ?? 1;

                    return (
                      <div
                        className="cc-cart-item"
                        key={cartItemId ?? index}
                      >
                        <div>
                          <strong>{itemName}</strong>
                          <small style={{ display: 'block' }}>
                            Qty: {itemQty}
                          </small>
                        </div>

                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '12px',
                          }}
                        >
                          <span>
                            ₹{(
                              Number(itemPrice) * Number(itemQty)
                            ).toLocaleString('en-IN', {
                              minimumFractionDigits: 2,
                            })}
                          </span>

                          <button
                            type="button"
                            onClick={() => removeFromCart(cartItemId)}
                            style={{
                              background: 'none',
                              border: 'none',
                              cursor: 'pointer',
                              fontSize: '16px',
                              color: '#ef4444',
                            }}
                          >
                            ×
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {cartItems.length > 0 && (
              <div className="cc-cart-footer">
                <div className="cc-cart-total">
                  <span>Subtotal:</span>
                  <strong>
                    ₹{cartSubtotal.toLocaleString('en-IN', {
                      minimumFractionDigits: 2,
                    })}
                  </strong>
                </div>

                {notice && (
                  <p className="cc-notice" role="status">
                    {notice}
                  </p>
                )}

                <button
                  type="button"
                  className="cc-primary-button cc-checkout-btn"
                  disabled={checkingOut}
                  onClick={handleRazorpayCheckout}
                >
                  {checkingOut ? 'Processing...' : 'Pay with Razorpay ↗'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      <section className="cc-hero">
        <div className="cc-hero-copy">
          <span className="cc-eyebrow">
            <span className="cc-eyebrow-dot" />
            MADE WITH HEART. FOUND BY YOU.
          </span>

          <h1>
            Stories made by hand.
            <br />
            <span>Made to be yours.</span>
          </h1>

          <p>
            Discover thoughtful handmade creations and the talented artisans
            behind every piece.
          </p>

          <a href="#marketplace" className="cc-primary-button">
            Explore the marketplace <span>↗</span>
          </a>
        </div>
      </section>

      <section className="cc-marketplace-section" id="marketplace">
        <div className="cc-section-heading">
          <div>
            <span className="cc-eyebrow">THE COLLECTION</span>
            <h2>
              Find your kind of <span>beautiful.</span>
            </h2>
          </div>

          {!loading && !error && (
            <span className="cc-results-count">
              {filteredProducts.length} creations
            </span>
          )}
        </div>

        <div className="cc-controls">
          <label className="cc-search">
            <span>⌕</span>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search treasures..."
            />
          </label>

          <select
            value={sort}
            onChange={(event) => setSort(event.target.value)}
            aria-label="Sort products"
          >
            <option value="featured">Featured</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
            <option value="name">Name</option>
          </select>
        </div>

        <div className="cc-category-list">
          {categories.map((name) => (
            <button
              type="button"
              key={name}
              className={category === name ? 'cc-category active' : 'cc-category'}
              onClick={() => setCategory(name)}
            >
              {name}
            </button>
          ))}
        </div>

        {notice && (
          <div className="cc-notice" role="status">
            <span>{notice}</span>
            <button type="button" onClick={() => setNotice('')}>
              ×
            </button>
          </div>
        )}

        {loading && (
          <div className="cc-state">
            <span className="cc-loader" />
            <p>Loading collection...</p>
          </div>
        )}

        {error && (
          <div className="cc-state cc-error">
            <p>{error}</p>
          </div>
        )}

        {!loading && !error && filteredProducts.length > 0 && (
          <div className="cc-product-grid">
            {filteredProducts.map((product, index) => {
              const id = product.productId ?? product.id ?? index;
              const name =
                product.productName || product.name || 'Handmade creation';
              const image = product.imageUrl || product.imageURL;
              const categoryName =
                product.categoryName || product.category?.name || 'Handcrafted';
              const artisanShop =
                product.artisanName ||
                product.artisan?.shopName ||
                product.artisan?.name ||
                'Local Artisan';
              const artisanId =
                product.artisanId || product.artisan?.id || 1;
              const price =
                product.variants?.[0]?.price ??
                product.productVariants?.[0]?.price ??
                product.price;

              const quantityInCart = cartItems
                .filter(
                  (item) =>
                    (item.productId ??
                      item.product?.id ??
                      item.product?.productId) === id
                )
                .reduce((sum, item) => sum + (item.quantity || 1), 0);

              const isWishlisted = wishlist.some(
                (item) => (item.productId ?? item.id) === id
              );

              return (
                <article className="cc-product-card" key={id}>
                  <div className="cc-product-visual">
                    {image ? (
                      <img src={image} alt={name} loading="lazy" />
                    ) : (
                      <div className="cc-product-placeholder">
                        <span>✿</span>
                      </div>
                    )}
                  </div>

                  <div className="cc-product-info">
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: '4px',
                      }}
                    >
                      <span className="cc-product-category">
                        {categoryName}
                      </span>

                      <Link
                        to={`/artisan/store/${artisanId}`}
                        style={{
                          fontSize: '0.78rem',
                          color: '#8c6d53',
                          fontWeight: '600',
                          textDecoration: 'underline',
                        }}
                      >
                        By {artisanShop}
                      </Link>
                    </div>

                    <h3>{name}</h3>
                    <p className="cc-product-description">
                      {product.description}
                    </p>

                    <div style={{ marginTop: '0.6rem', marginBottom: '0.5rem' }}>
                      <label
                        style={{
                          fontSize: '0.75rem',
                          color: '#666',
                          fontWeight: '500',
                          display: 'block',
                          marginBottom: '3px',
                        }}
                      >
                        ✏️ Customization / Engraving (Optional):
                      </label>

                      <input
                        type="text"
                        placeholder="e.g. Engrave 'A & S', Blue color..."
                        value={customizations[id] || ''}
                        onChange={(event) =>
                          setCustomizations((previous) => ({
                            ...previous,
                            [id]: event.target.value,
                          }))
                        }
                        style={{
                          width: '100%',
                          padding: '0.4rem 0.6rem',
                          fontSize: '0.8rem',
                          border: '1px solid #dcd6cd',
                          borderRadius: '6px',
                          outline: 'none',
                          backgroundColor: '#fcfbfa',
                        }}
                      />
                    </div>

                    <div
                      className="cc-product-bottom"
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginTop: '1rem',
                      }}
                    >
                      <div className="cc-price">
                        {price != null
                          ? `₹${Number(price).toLocaleString('en-IN', {
                              minimumFractionDigits: 2,
                            })}`
                          : 'Price unavailable'}
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        {quantityInCart > 0 && (
                          <span
                            style={{
                              backgroundColor: '#8c6d53',
                              color: '#fff',
                              borderRadius: '12px',
                              padding: '2px 8px',
                              fontSize: '0.75rem',
                              fontWeight: 'bold',
                            }}
                          >
                            {quantityInCart} in cart
                          </span>
                        )}

                        <button
                          type="button"
                          className="cc-add-button"
                          disabled={addingId === id}
                          onClick={() => addToCart(product)}
                        >
                          {addingId === id ? '…' : '+'}
                        </button>

                        <button
                          type="button"
                          aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                          onClick={() => toggleWishlist(product)}
                        >
                          {isWishlisted ? '♥' : '♡'}
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {!loading && !error && filteredProducts.length === 0 && (
          <div className="cc-state">
            <p>No creations found. Try another search or category.</p>
          </div>
        )}
      </section>
    </main>
  );
}
