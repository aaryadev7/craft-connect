
import { useEffect, useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';

export default function ArtisanDashboard() {
  const [products, setProducts] = useState([]);
  const [reels, setReels] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Header / Profile Dropdown State
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const profileDropdownRef = useRef(null);
  const navigate = useNavigate();

  // Load artisan products, reels, received orders, and cart count
  useEffect(() => {
    async function fetchArtisanData() {
      try {
        setLoading(true);

        const [productData, reelData, cartData, orderData] =
          await Promise.all([
            apiRequest('/api/products/my-products').catch(() => []),
            apiRequest('/api/artisan/reels').catch(() => []),
            apiRequest('/api/cart/details').catch(() => null),
            apiRequest('/api/artisan/orders').catch(() => []),
          ]);

        const productList = Array.isArray(productData)
          ? productData
          : productData?.content ?? [];

        setProducts(productList);

        const reelList = Array.isArray(reelData)
          ? reelData
          : reelData?.content ?? [];

        setReels(reelList);

        const orderList = Array.isArray(orderData)
          ? orderData
          : orderData?.content ?? [];

        setOrders(orderList);

        const items = cartData?.items ?? [];
        const totalQty = items.reduce(
          (sum, item) => sum + (item.quantity || 1),
          0
        );

        setCartCount(totalQty);
      } catch (err) {
        setError(
          err.message || 'Unable to load artisan dashboard data.'
        );
      } finally {
        setLoading(false);
      }
    }

    fetchArtisanData();
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (
        profileDropdownRef.current &&
        !profileDropdownRef.current.contains(event.target)
      ) {
        setIsProfileOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);

    return () =>
      document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleLogout() {
    localStorage.removeItem('craft_connect_token');
    localStorage.removeItem('craft_connect_role');
    window.location.href = '/artisan/login';
  }

  // Calculate sales summary
  const totalListings = products.length;
  const totalReels = reels.length;
  const totalOrders = orders.length;

  return (
    <main
      className="artisan-dashboard-page"
      style={{
        padding: '2rem 5%',
        maxWidth: '1200px',
        margin: '0 auto',
        fontFamily: 'sans-serif',
      }}
    >
      {/* Header Navigation with Profile Dropdown */}
      <header
        className="shop-header"
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '2.5rem',
        }}
      >
        <Link
          to="/"
          className="shop-brand"
          style={{
            fontSize: '1.5rem',
            fontWeight: 'bold',
            textDecoration: 'none',
            color: '#2c2523',
          }}
        >
          Craft Connect<span style={{ color: '#8c6d53' }}>.</span>
        </Link>

        <nav
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1.5rem',
          }}
        >
          <Link
            to="/artisan/add-product"
            style={{
              textDecoration: 'none',
              color: '#2c2523',
              fontWeight: '500',
            }}
          >
            + Add Product
          </Link>

          <Link
            to="/artisan/add-reel"
            style={{
              textDecoration: 'none',
              color: '#2c2523',
              fontWeight: '500',
            }}
          >
            🎬 Upload Reel
          </Link>

          {/* Profile Dropdown Menu */}
          <div
            className="profile-menu-container"
            ref={profileDropdownRef}
            style={{ position: 'relative' }}
          >
            <button
              type="button"
              className="profile-icon-btn"
              onClick={() =>
                setIsProfileOpen((prev) => !prev)
              }
              aria-label="User Account Menu"
              style={{
                background: '#f4efe8',
                border: '1px solid #dcd6cd',
                borderRadius: '50%',
                width: '40px',
                height: '40px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.1rem',
              }}
            >
              👤
            </button>

            {isProfileOpen && (
              <div
                className="profile-dropdown-menu"
                style={{
                  position: 'absolute',
                  right: 0,
                  top: '120%',
                  width: '210px',
                  backgroundColor: '#ffffff',
                  border: '1px solid #e5e0d8',
                  borderRadius: '12px',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
                  zIndex: 1000,
                  padding: '0.5rem 0',
                  display: 'flex',
                  flexDirection: 'column',
                }}
              >
                <div
                  style={{
                    padding: '0.5rem 1rem',
                    borderBottom: '1px solid #f0ebe1',
                  }}
                >
                  <strong
                    style={{
                      fontSize: '0.75rem',
                      color: '#888',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px',
                    }}
                  >
                    Artisan Studio
                  </strong>
                </div>

                {/* Cart Option */}
                <Link
                  to="/customer/cart"
                  onClick={() => setIsProfileOpen(false)}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '0.65rem 1rem',
                    color: '#2c2523',
                    textDecoration: 'none',
                    fontSize: '0.95rem',
                  }}
                >
                  <span>🛒 Cart</span>

                  {cartCount > 0 && (
                    <span
                      style={{
                        background: '#8c6d53',
                        color: '#ffffff',
                        borderRadius: '10px',
                        padding: '2px 8px',
                        fontSize: '0.75rem',
                        fontWeight: 'bold',
                      }}
                    >
                      {cartCount}
                    </span>
                  )}
                </Link>

                {/* Track Order Option */}
                <Link
                  to="/customer/track-order"
                  onClick={() => setIsProfileOpen(false)}
                  style={{
                    padding: '0.65rem 1rem',
                    color: '#2c2523',
                    textDecoration: 'none',
                    fontSize: '0.95rem',
                  }}
                >
                  📍 Track Order
                </Link>

                <hr
                  style={{
                    margin: '0.4rem 0',
                    border: 'none',
                    borderTop: '1px solid #f0ebe1',
                  }}
                />

                {/* Sign Out Option */}
                <button
                  type="button"
                  onClick={() => {
                    setIsProfileOpen(false);
                    handleLogout();
                  }}
                  style={{
                    background: 'none',
                    border: 'none',
                    textAlign: 'left',
                    padding: '0.65rem 1rem',
                    color: '#d9534f',
                    cursor: 'pointer',
                    width: '100%',
                    fontSize: '0.95rem',
                    fontWeight: '500',
                  }}
                >
                  🚪 Sign out
                </button>
              </div>
            )}
          </div>
        </nav>
      </header>

      {/* Overview Stats Bar */}
      <section
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1.5rem',
          marginBottom: '3rem',
        }}
      >
        <div
          style={{
            background: '#faf8f5',
            border: '1px solid #eee7de',
            padding: '1.5rem',
            borderRadius: '12px',
          }}
        >
          <small style={{ color: '#888', textTransform: 'uppercase' }}>
            Active Listings
          </small>
          <h2
            style={{
              fontSize: '2rem',
              margin: '0.5rem 0 0',
              color: '#2c2523',
            }}
          >
            {totalListings}
          </h2>
        </div>

        <div
          style={{
            background: '#faf8f5',
            border: '1px solid #eee7de',
            padding: '1.5rem',
            borderRadius: '12px',
          }}
        >
          <small style={{ color: '#888', textTransform: 'uppercase' }}>
            Craft Stories / Reels
          </small>
          <h2
            style={{
              fontSize: '2rem',
              margin: '0.5rem 0 0',
              color: '#2c2523',
            }}
          >
            {totalReels}
          </h2>
        </div>

        <div
          style={{
            background: '#faf8f5',
            border: '1px solid #eee7de',
            padding: '1.5rem',
            borderRadius: '12px',
          }}
        >
          <small style={{ color: '#888', textTransform: 'uppercase' }}>
            Orders Received
          </small>
          <h2
            style={{
              fontSize: '2rem',
              margin: '0.5rem 0 0',
              color: '#2c2523',
            }}
          >
            {totalOrders}
          </h2>
        </div>
      </section>

      {/* Received Orders & Customization Requests Section */}
      {orders.length > 0 && (
        <section style={{ marginBottom: '3rem' }}>
          <h2
            style={{
              marginBottom: '1.5rem',
              color: '#2c2523',
            }}
          >
            📦 Received Orders & Customizations
          </h2>

          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '1rem',
            }}
          >
            {orders.map((order) => (
              <div
                key={order.id || order.orderId}
                style={{
                  border: '1px solid #e5e0d8',
                  borderRadius: '12px',
                  padding: '1.25rem',
                  backgroundColor: '#faf8f5',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    marginBottom: '0.75rem',
                    borderBottom: '1px solid #eee',
                    paddingBottom: '0.5rem',
                  }}
                >
                  <strong>Order #{order.orderId || order.id}</strong>

                  <span
                    style={{
                      color: '#8c6d53',
                      fontWeight: 'bold',
                    }}
                  >
                    Status: {order.status || 'PAID'}
                  </span>
                </div>

                <div>
                  {(order.items || order.orderItems || []).map(
                    (item, idx) => (
                      <div
                        key={idx}
                        style={{
                          margin: '0.5rem 0',
                          padding: '0.5rem',
                          backgroundColor: '#ffffff',
                          borderRadius: '8px',
                          border: '1px solid #f0ebe1',
                        }}
                      >
                        <p
                          style={{
                            margin: 0,
                            fontWeight: 'bold',
                          }}
                        >
                          {item.productName || item.name} (x
                          {item.quantity || 1})
                        </p>

                        {(item.customizationNote || item.notes) && (
                          <div
                            style={{
                              marginTop: '4px',
                              padding: '6px 10px',
                              backgroundColor: '#fff8ef',
                              borderLeft: '3px solid #8c6d53',
                              borderRadius: '4px',
                              fontSize: '0.85rem',
                            }}
                          >
                            <strong>
                              ✏️ Customer Customization Request:
                            </strong>{' '}
                            "{item.customizationNote || item.notes}"
                          </div>
                        )}
                      </div>
                    )
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Main Content: Products List */}
      <section>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '1.5rem',
          }}
        >
          <h2>Your Creations</h2>

          <button
            onClick={() => navigate('/artisan/add-product')}
            style={{
              backgroundColor: '#8c6d53',
              color: '#ffffff',
              border: 'none',
              padding: '0.6rem 1.2rem',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            + Create New Listing
          </button>
        </div>

        {loading && <p>Loading your products...</p>}

        {error && <p style={{ color: 'red' }}>{error}</p>}

        {!loading && !error && products.length === 0 && (
          <div
            style={{
              textAlign: 'center',
              padding: '3rem',
              border: '2px dashed #ddd',
              borderRadius: '12px',
            }}
          >
            <p style={{ color: '#666' }}>
              You haven't added any products yet.
            </p>

            <button
              onClick={() => navigate('/artisan/add-product')}
              style={{
                marginTop: '1rem',
                backgroundColor: '#8c6d53',
                color: '#ffffff',
                border: 'none',
                padding: '0.6rem 1.2rem',
                borderRadius: '8px',
                cursor: 'pointer',
              }}
            >
              Add Your First Product
            </button>
          </div>
        )}

        {!loading && products.length > 0 && (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
              gap: '1.5rem',
            }}
          >
            {products.map((product) => {
              const id = product.productId ?? product.id;
              const name = product.productName || product.name;
              const price =
                product.price ?? product.variants?.[0]?.price;
              const image = product.imageUrl || product.imageURL;

              return (
                <div
                  key={id}
                  style={{
                    border: '1px solid #eee',
                    borderRadius: '12px',
                    overflow: 'hidden',
                    backgroundColor: '#fff',
                  }}
                >
                  <div
                    style={{
                      width: '100%',
                      height: '180px',
                      backgroundColor: '#f0f0f0',
                    }}
                  >
                    {image ? (
                      <img
                        src={image}
                        alt={name}
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                        }}
                      />
                    ) : (
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          height: '100%',
                          color: '#aaa',
                        }}
                      >
                        No Image
                      </div>
                    )}
                  </div>

                  <div style={{ padding: '1rem' }}>
                    <h3
                      style={{
                        fontSize: '1.1rem',
                        margin: '0 0 0.5rem',
                        color: '#2c2523',
                      }}
                    >
                      {name}
                    </h3>

                    <p
                      style={{
                        fontWeight: 'bold',
                        color: '#8c6d53',
                        margin: 0,
                      }}
                    >
                      ₹{Number(price || 0).toLocaleString('en-IN')}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </main>
  );
}
