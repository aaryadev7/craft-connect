
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { apiRequest } from '../services/api';
import { uploadImage } from '../services/cloudinary';

import './AddProduct.css';

export default function AddProduct() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    productName: '',
    categoryId: '',
    price: '',
    description: '',
    customizable: false,
  });

  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  function handleChange(event) {
    const { name, value, type, checked } = event.target;

    setForm((previous) => ({
      ...previous,
      [name]: type === 'checkbox' ? checked : value,
    }));
  }

  function handleImageChange(event) {
    const file = event.target.files?.[0];

    setError('');
    setImage(file || null);

    if (preview) {
      URL.revokeObjectURL(preview);
    }

    if (file) {
      if (!file.type.startsWith('image/')) {
        setImage(null);
        setPreview('');
        setError('Please select a valid image file.');
        event.target.value = '';
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        setImage(null);
        setPreview('');
        setError('Image size must be 5 MB or less.');
        event.target.value = '';
        return;
      }

      setPreview(URL.createObjectURL(file));
    } else {
      setPreview('');
    }
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setSuccess('');

    const price = Number(form.price);
    const categoryId = Number(form.categoryId);

    if (!form.productName.trim()) {
      setError('Please enter a product name.');
      return;
    }

    if (!Number.isInteger(categoryId) || categoryId <= 0) {
      setError('Enter a valid category ID.');
      return;
    }

    if (!Number.isFinite(price) || price <= 0) {
      setError('Enter a valid price greater than zero.');
      return;
    }

    if (!image) {
      setError('Please select a product image.');
      return;
    }

    setLoading(true);

    try {
      // Upload the image first and get its Cloudinary URL.
      const imageUrl = await uploadImage(image);

      if (!imageUrl) {
        throw new Error('Image upload did not return a URL.');
      }

      // The backend obtains artisanId from the authenticated user.
      await apiRequest('/api/products', {
        method: 'POST',
        body: JSON.stringify({
          productName: form.productName.trim(),
          categoryId,
          price,
          description: form.description.trim(),
          customizable: form.customizable,
          status: 'ACTIVE',
          imageUrl,
        }),
      });

      setSuccess('Product added successfully!');

      // Return to the dashboard after showing the success message.
      setTimeout(() => {
        navigate('/artisan/dashboard');
      }, 800);
    } catch (err) {
      setError(
        err.message || 'Unable to add product. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="add-product-page">
      <div className="add-product-container">
        <Link
          to="/artisan/dashboard"
          className="add-product-back"
        >
          ← Back to dashboard
        </Link>

        <header className="add-product-header">
          <p className="add-product-eyebrow">
            ARTISAN WORKSPACE
          </p>

          <h1>Add a new product</h1>

          <p>
            Share your handmade creation with the Craft Connect
            community.
          </p>
        </header>

        <form
          className="add-product-form"
          onSubmit={handleSubmit}
        >
          <div className="add-product-field">
            <label htmlFor="productName">
              Product name *
            </label>

            <input
              id="productName"
              name="productName"
              type="text"
              value={form.productName}
              onChange={handleChange}
              placeholder="e.g. Hand-painted ceramic vase"
              maxLength={150}
              required
            />
          </div>

          <div className="add-product-field">
            <label htmlFor="categoryId">
              Category ID *
            </label>

            <input
              id="categoryId"
              name="categoryId"
              type="number"
              min="1"
              step="1"
              value={form.categoryId}
              onChange={handleChange}
              placeholder="Enter an existing category ID"
              required
            />

            <small>
              Use a category ID that already exists in your
              database.
            </small>
          </div>

          <div className="add-product-field">
            <label htmlFor="price">Price (₹) *</label>

            <input
              id="price"
              name="price"
              type="number"
              min="0.01"
              step="0.01"
              value={form.price}
              onChange={handleChange}
              placeholder="e.g. 799"
              required
            />
          </div>

          <div className="add-product-field">
            <label htmlFor="description">
              Product description
            </label>

            <textarea
              id="description"
              name="description"
              value={form.description}
              onChange={handleChange}
              placeholder="Describe the materials, technique, and story behind your product..."
              rows={5}
              maxLength={2000}
            />
          </div>

          <div className="add-product-field">
            <label htmlFor="productImage">
              Product image *
            </label>

            <input
              id="productImage"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              required
            />

            {preview && (
              <div className="add-product-preview">
                <img
                  src={preview}
                  alt="Selected product preview"
                />
              </div>
            )}
          </div>

          <label className="add-product-checkbox">
            <input
              type="checkbox"
              name="customizable"
              checked={form.customizable}
              onChange={handleChange}
            />

            <span>
              This product can be customized
            </span>
          </label>

          {error && (
            <p className="add-product-error" role="alert">
              {error}
            </p>
          )}

          {success && (
            <p className="add-product-success" role="status">
              {success}
            </p>
          )}

          <button
            type="submit"
            className="add-product-submit"
            disabled={loading}
          >
            {loading
              ? 'Uploading image and saving...'
              : 'Add product'}
          </button>
        </form>
      </div>
    </main>
  );
}
