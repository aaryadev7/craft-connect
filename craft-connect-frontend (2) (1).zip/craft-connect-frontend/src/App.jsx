
import { useState } from 'react';
import {
  BrowserRouter,
  Link,
  Navigate,
  Route,
  Routes,
  useNavigate,
} from 'react-router-dom';

import { apiRequest } from './services/api';
import ArtisanStorefrontPage from './pages/ArtisanStorefrontPage';

import Register from './pages/Register';
import ArtisanRegister from './pages/ArtisanRegister';
import CustomerDashboard from './pages/CustomerDashboard';
import ArtisanDashboard from './pages/ArtisanDashboard';
import AdminDashboard from './pages/AdminDashboard';
import AddProduct from './pages/AddProduct';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import OrderConfirmation from './pages/OrderConfirmation';
import TrackOrderPage from './pages/TrackOrderPage';

import './auth.css';

const ROLES = {
  customer: 'CUSTOMER',
  artisan: 'ARTISAN',
  admin: 'ADMIN',
};

const PORTALS = [
  {
    key: 'customer',
    title: 'Customer',
    description: 'Discover handmade products and manage your orders.',
  },
  {
    key: 'artisan',
    title: 'Artisan',
    description: 'Showcase your craft and manage your products.',
  },
  {
    key: 'admin',
    title: 'Admin',
    description: 'Manage and oversee the marketplace.',
  },
];

// Normalize common role formats returned by JWTs or login responses.
function normalizeRole(value) {
  if (Array.isArray(value)) {
    for (const item of value) {
      const role = normalizeRole(item);
      if (role) return role;
    }
    return '';
  }

  if (value && typeof value === 'object') {
    return normalizeRole(
      value.authority ?? value.role ?? value.name ?? ''
    );
  }

  return String(value ?? '')
    .trim()
    .replace(/^ROLE_/i, '')
    .toUpperCase();
}

// Read the role from the JWT payload.
function getRoleFromToken(token) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3 || !parts[1]) return '';

    const base64 = parts[1]
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const padded = base64.padEnd(
      base64.length + ((4 - (base64.length % 4)) % 4),
      '='
    );

    const binary = atob(padded);

    const bytes = Uint8Array.from(
      binary,
      (character) => character.charCodeAt(0)
    );

    const payload = JSON.parse(
      new TextDecoder().decode(bytes)
    );

    return normalizeRole(
      payload.role ??
        payload.roles ??
        payload.authorities ??
        payload.authority ??
        ''
    );
  } catch {
    return '';
  }
}

function Home() {
  return (
    <main className="home-page">
      <nav className="navbar">
        <Link to="/" className="brand">
          Craft Connect<span>.</span>
        </Link>

        <a className="nav-home-link" href="#portals">
          Choose your portal
        </a>
      </nav>

      <section className="hero">
        <p className="eyebrow">CRAFT CONNECT MARKETPLACE</p>

        <h1>
          Every craft has
          <br />
          a story to <span>tell.</span>
        </h1>

        <p className="hero-description">
          Connect with artisans and discover the people behind
          handmade creations.
        </p>

        <a className="primary-link" href="#portals">
          Get started <span aria-hidden="true">→</span>
        </a>
      </section>

      <section className="portals" id="portals">
        <div className="section-heading">
          <p className="eyebrow">WELCOME</p>
          <h2>Choose your portal</h2>
          <p>Sign in or create an account to get started.</p>
        </div>

        <div className="portal-grid">
          {PORTALS.map((portal, index) => (
            <article className="portal-card" key={portal.key}>
              <span className="portal-number">
                {String(index + 1).padStart(2, '0')}
              </span>

              <h3>{portal.title}</h3>
              <p>{portal.description}</p>

              <Link
                to={`/${portal.key}/login`}
                className="portal-link"
              >
                Sign in <span aria-hidden="true">→</span>
              </Link>

              {portal.key === 'customer' && (
                <Link
                  to="/customer/register"
                  className="portal-link"
                >
                  Create customer account →
                </Link>
              )}

              {portal.key === 'artisan' && (
                <Link
                  to="/artisan/register"
                  className="portal-link"
                >
                  Join as an Artisan →
                </Link>
              )}
            </article>
          ))}
        </div>
      </section>

      <footer className="footer">
        Craft Connect · Connecting creativity with community.
      </footer>
    </main>
  );
}

function Login({ role }) {
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const roleName = role.charAt(0).toUpperCase() + role.slice(1);

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setLoading(true);

    try {
      const data = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          email: email.trim(),
          password,
        }),
      });

      if (!data?.token || typeof data.token !== 'string') {
        throw new Error(
          'The backend did not return an authentication token.'
        );
      }

      const responseRole = normalizeRole(
        data.role ??
          data.roles ??
          data.authorities ??
          ''
      );

      const tokenRole = getRoleFromToken(data.token);
      const actualRole = responseRole || tokenRole;

      if (!actualRole) {
        throw new Error(
          'Login succeeded, but the user role could not be identified.'
        );
      }

      if (actualRole !== ROLES[role]) {
        throw new Error(
          `This account has the ${actualRole} role. Please use the ${roleName} portal.`
        );
      }

      localStorage.setItem('craft_connect_token', data.token);
      localStorage.setItem('craft_connect_role', actualRole);

      navigate(`/${role}/dashboard`, { replace: true });
    } catch (err) {
      setError(
        err.message || 'Unable to sign in. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="auth-page">
      <section className="auth-card">
        <Link to="/" className="back-link">
          ← Craft Connect
        </Link>

        <p className="eyebrow">{roleName.toUpperCase()} PORTAL</p>
        <h1>Welcome back.</h1>

        <p className="auth-description">
          Sign in to continue to your {role} account.
        </p>

        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor={`${role}-email`}>Email address</label>
            <input
              id={`${role}-email`}
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              autoComplete="email"
              placeholder="you@example.com"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor={`${role}-password`}>Password</label>
            <input
              id={`${role}-password`}
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete="current-password"
              placeholder="Enter your password"
              required
            />
          </div>

          {error && (
            <p className="login-error" role="alert">
              {error}
            </p>
          )}

          <button
            className="primary-button"
            type="submit"
            disabled={loading}
          >
            {loading ? 'Signing in...' : 'Sign in'}
            {!loading && <span aria-hidden="true"> →</span>}
          </button>
        </form>

        {role === 'customer' && (
          <p className="auth-footer">
            New to Craft Connect?{' '}
            <Link to="/customer/register">Create an account</Link>
          </p>
        )}

        {role === 'artisan' && (
          <p className="auth-footer">
            New artisan?{' '}
            <Link to="/artisan/register">Join Craft Connect</Link>
          </p>
        )}

        <div className="portal-switch">
          <span>Other portals</span>
          <div>
            {PORTALS.filter((portal) => portal.key !== role).map(
              (portal) => (
                <Link
                  key={portal.key}
                  to={`/${portal.key}/login`}
                >
                  {portal.title}
                </Link>
              )
            )}
          </div>
        </div>
      </section>
    </main>
  );
}

function ProtectedRoute({ role, children }) {
  const token = localStorage.getItem('craft_connect_token');

  const savedRole = normalizeRole(
    localStorage.getItem('craft_connect_role')
  );

  if (!token || savedRole !== ROLES[role]) {
    return <Navigate to={`/${role}/login`} replace />;
  }

  return children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />

      <Route
        path="/customer/login"
        element={<Login role="customer" />}
      />

      <Route
        path="/artisan/login"
        element={<Login role="artisan" />}
      />

      <Route
        path="/admin/login"
        element={<Login role="admin" />}
      />

      {/* Public artisan storefront */}
      <Route
        path="/artisan/store/:artisanId"
        element={<ArtisanStorefrontPage />}
      />

      <Route
        path="/customer/register"
        element={<Register />}
      />

      <Route
        path="/artisan/register"
        element={<ArtisanRegister />}
      />

      <Route
        path="/customer/dashboard"
        element={
          <ProtectedRoute role="customer">
            <CustomerDashboard />
          </ProtectedRoute>
        }
      />

      <Route
        path="/customer/cart"
        element={
          <ProtectedRoute role="customer">
            <CartPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/customer/checkout"
        element={
          <ProtectedRoute role="customer">
            <CheckoutPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/customer/order-confirmation"
        element={
          <ProtectedRoute role="customer">
            <OrderConfirmation />
          </ProtectedRoute>
        }
      />

      <Route
        path="/customer/track-order"
        element={
          <ProtectedRoute role="customer">
            <TrackOrderPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/artisan/dashboard"
        element={
          <ProtectedRoute role="artisan">
            <ArtisanDashboard />
          </ProtectedRoute>
        }
      />

      {/* Added missing Add Product route */}
      <Route
        path="/artisan/add-product"
        element={
          <ProtectedRoute role="artisan">
            <AddProduct />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/dashboard"
        element={
          <ProtectedRoute role="admin">
            <AdminDashboard />
          </ProtectedRoute>
        }
      />

      <Route
        path="*"
        element={<Navigate to="/" replace />}
      />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}
